package com.android.stmx.myapp

data class Owner(
        val id:String,
        val name:String,
        val numPhone:String,
        val telegram:String,
        val gender:String
)