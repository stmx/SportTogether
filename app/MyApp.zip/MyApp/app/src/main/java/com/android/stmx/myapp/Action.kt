package com.android.stmx.myapp

data class Action(
        val id:String,
        val idOwner:String,
        val date:String,
        val time:String,
        val description:String,
        val needPeople:Int,
        val payment:Int,
        val place:String,
        val sport:String
)